const products = [
    { id: 1, name: "মধু (Pure Honey)", price: 450, img: "https://via.placeholder.com/200" },
    { id: 2, name: "আমলকি গুঁড়া", price: 250, img: "https://via.placeholder.com/200" },
    { id: 3, name: "কালোজিরা তেল", price: 350, img: "https://via.placeholder.com/200" },
    { id: 4, name: "হাড়জোড়া গুঁড়া", price: 280, img: "https://via.placeholder.com/200" },
    { id: 5, name: "শিলাজিত", price: 650, img: "https://via.placeholder.com/200" },
    { id: 6, name: "অশ্বগন্ধা", price: 500, img: "https://via.placeholder.com/200" },
    { id: 7, name: "ত্রিফলা চূর্ণ", price: 320, img: "https://via.placeholder.com/200" },
    { id: 8, name: "নিম পাতা গুঁড়া", price: 220, img: "https://via.placeholder.com/200" },
    { id: 9, name: "তুলসি সিরাপ", price: 180, img: "https://via.placeholder.com/200" },
    { id: 10, name: "মেথি গুঁড়া", price: 160, img: "https://via.placeholder.com/200" },
    { id: 11, name: "খেজুর গুড়", price: 300, img: "https://via.placeholder.com/200" },
    { id: 12, name: "ডাবের ভিনেগার", price: 400, img: "https://via.placeholder.com/200" }
];

let cart = JSON.parse(localStorage.getItem('cart')) || [];

function loadProducts() {
    const pDisplay = document.getElementById('product-display');
    if(!pDisplay) return;
    pDisplay.innerHTML = products.map(p => `
        <div class="col-6 col-md-3">
            <div class="card product-card h-100 p-2">
                <img src="${p.img}" class="card-img-top rounded">
                <div class="card-body p-2 text-center">
                    <h6 class="fw-bold mb-1">${p.name}</h6>
                    <p class="text-success fw-bold mb-2">৳ ${p.price}</p>
                    <button onclick="addToCart(${p.id})" class="btn btn-sm btn-success w-100 rounded-pill">কার্টে যুক্ত করুন</button>
                </div>
            </div>
        </div>
    `).join('');
}

function addToCart(id) {
    const p = products.find(i => i.id === id);
    cart.push(p);
    localStorage.setItem('cart', JSON.stringify(cart));
    updateCartCount();
    alert("পণ্যটি কার্টে যুক্ত হয়েছে!");
}

function updateCartCount() {
    const count = document.getElementById('cart-count');
    if(count) count.innerText = cart.length;
}

window.onload = () => { loadProducts(); updateCartCount(); };
